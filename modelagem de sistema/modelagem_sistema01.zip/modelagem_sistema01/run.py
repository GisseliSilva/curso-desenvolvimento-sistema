from controller import inicio

if __name__=="__main__":
    inicio()
